@echo off
cd /d "%~dp0"
repair.exe -c config.json
pause
